#from teamupNew import *
import sys
import argparse
import time
sys.path.append(  "../../")
from teamup import *


DEBUG = 1


HEADERS = {'Teamup-Token': APIkey}
H2 = {'Teamup-Token': APIkey, 'Content-type': "application/json"}
calendar = None



def truncateSubCals(calendar, noPrompt):
    PARAMS = []
    i = 1
    if calendar == "":
        calendar = calendarPicker("Pick a Calendar a to TRUNCATE")
        name = calIDToName(calendar)
        x = input("Deleting all rides and sub calendars from  " + name + " Continue? (y/n)")
        if x != 'y':
            exit()
    name = calIDToName(calendar)

    if noPrompt == False:
        x = input("Just double checking, so for sure you want to delete everything in : " + name + "? (y/n)")
        if x != 'y':
            exit()
    if name == None:
        name = calendar

    calendars = getSubCalendars(calendar)
    config = getConfig(calendar)
    params = ""

    calCount = 1
    firstTime = True
    for cal in calendars:
        if DEBUG == 2:
            print ("cal:", cal)
            print("\t", cal['id'])
        params = '/' + str(cal['id'])

        calCount += 1

        print("All rides for", cal['name'], end="")
        save = cal.copy()
        #del save['id']
    #    del save['creation_dt']
    #    save['update_dt'] = None
    #    save['attributes'] = []
        # del save['remote_id']
        # del save['delete_dt']
        # del save['version']
        # rel save['series_id']
        deleted = queryTeamup(UPDATE_HEADERS, calendar,
                              'delete', 'subcalendars', params, "")
        if  isinstance(deleted, str) and deleted.find("204") == -1:
            print(deleted)
        else:
            print(" and the calendar Successfully Deleted ")
            if firstTime == True:
                time.sleep(3)
                firstTime = False
                print("Trying to restore " + save['name'], end=" ")
                res = queryTeamup(UPDATE_HEADERS, calendar, 'post', 'subcalendars', "", save)
                print("Restored ")

    # print("Completed")
    # for x in calendarsToLoad:
        # print("cal list: ", x, " ", cal['name'])
        # if x == cal['name']:
        # res = queryTeamup(UPDATE_HEADERS, calendar, 'post', 'subcalendars', params, cal)
        # if res.get('subcalenar'):
            # results = res['subcalendar']
        # elif res.get('error'):
            # print(res['error'])
            # for cal in calendars:
                # print("Processing: ", keyValue(cal, 'name'))
                # params = ""
                # type = 'subcalendars'
                # if insertSubCals == True:
                # for x in calendarsToLoad:
                # print("cal list: ", x, " ", cal['name'])
                # if x == cal['name']:
                # res = queryTeamup(UPDATE_HEADERS, calendar, 'post', 'subcalendars', params, cal)
                # if res.get('subcalenar'):
                # results = res['subcalendar']
                # elif res.get('error'):
                # print(res['error'])
                # else:
                # printEvent(calendar, 'name')
def main(argv):
    calendar = None
    try:
        opts, args = getopt.gnu_getopt(sys.argv[1:], "sr")
    except getopt.GetoptError:
        print (os.path.basename(sys.argv[0]), '[-s)delete subcalendars -r)delete rides [calendarName]')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('test.py -i <inputfile> -o <outputfile>')
            sys.exit()
        elif opt in ("-s"):
            deleteSubCals = True
        elif opt in ("-r"):
            deleteRides = True
    calendar = ""
    if len(args) > 0:
         calendar = args[0]
    truncate(calendar)

if __name__ == "__main__":
    main(sys.argv[0:])
