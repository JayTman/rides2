if __name__ == "__main__":
    import os
    import sys
    sys.path.insert(0, os.path.dirname("../"))
    from teamup import *

from truncateSubCalendars import *
from restoreSubCalendar import *
from restoreRides import *


def  reloadTestCalendar(toCal, restoreCalendar, noPrompt):
    
    #toCal = "ksbmqapicnorxb63e1"
    #fileName = dataDir + "../utils/reloadCalendar/KEEP.jsn"
    #toCal = "ks6khpzm4r5rmpqesc"
    fileName = dataDir + restoreCalendar
    print(fileName +  " " + toCal)
    truncateSubCals(toCal, noPrompt)
    loadSubCals(fileName, toCal)
    restoreRides(fileName, toCal)
    return("Restore is Done");


def main(argv):

    fileName = "vueTest"


if __name__ == "__main__":
    main(sys.argv[1:])


