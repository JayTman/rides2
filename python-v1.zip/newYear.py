from teamup import *
import datetime as dt
from dateutil.parser import parse
from urllib.parse import quote_plus
#from urllib.parse import quote
import os
#colheading <background:gold; color:green}

def resetNewYear(calendar, nextYear, msg = ""):
    today = dt.date.today()
    month = today.month
    day = today.day

    lastYear = int(nextYear) - 1
    print("YEARS" , lastYear,"  ",  nextYear)
        #  if repeat is yearly disconnect from pattern
    # disconnect perevious year
    startDate = dt.date(lastYear, 6, 1)
    endDate = dt.date(lastYear, 12, 31)
    events = getEvents(calendar, startDate, endDate)
    for event in events:
        if event['rrule'].find('YEAR') > -1:
            #print("ungrouping: ", event['start_dt'], " " , event['title'])
            if msg == 'undo':
                event['reddit'] = "all"
            else:
                event['reddit'] = "single"

            results = updateEvent(calendar, event)
            if isinstance(results , str):
                print(results)


    statusID, valueID = customNameToID({'status': ['choices']})
    statusID, confirmID = customNameToID({'Status': ['Confirmed'][0]})
    statusID, changeID = customNameToID({'Status: ': ['change'][0]})
    statusID, pendID = customNameToID({'Status: ': ['pend'][0]})
    #print(confirmID, " ", changeID, " ", pendID)
    startDate = dt.date(int(nextYear), 1, 1)
    endDate = dt.date(int(nextYear), 12, 31)
    events = getEvents(calendar, startDate, endDate)

    #print("updating status", startDate, " ", endDate)
    for event in events:
        if event['rrule'].find('YEAR') == -1:
            continue
#        if event['who'] == "":
#            continue
#        if event['rrule'].find('WEEK') > -1:
#            continue
#        if event['rrule'] == None:
#            continue
        if 'custom' in event:
            if statusID in event['custom']:
                if event['custom'][statusID][0] !=  changeID and \
                   event['custom'][statusID][0] !=  confirmID: # and \
                   #event['custom'][statusID][0] !=  pendID:
                    continue
                event['custom'][statusID].clear()
                #print("changing status" , event['who'], event['title'] )
                event['custom'][statusID].append(pendID)
                    # event['remote_id'] =  pendID
                event['redit'] = "all"
                results = updateEvent(calendar, event)
                #print("updating ", event['start_dt'], " " , event['title'], "to", event['custom'][statusID])
                if isinstance(results , str):
                    print(results)


def newYear(calendar, rideID):
    if calendar == "":
        calendar = calendarPicker("New Year:")

    file = open( FSRoot + "/newYear.css", "r")
    htmlHeader = file.read()
    file.close()
    lastReset="1/1/1901"
    # fp = resetLockFile
    # if os.path.exists(fp):
    #     file = open(resetLockFile, "r")
    #     lastReset = file.read()
    #     file.close()
    # else:
    #     file = open(resetLockFile, "w")
    #     file.write(lastReset)
    #     file.close()
    # current year if in Jan or Feb


    today = dt.date.today()
    year = today.year
    month = today.month
    day = today.day
    if today.month < 7:
        lastYear = year - 1
        nextYear = year
    else:
        lastYear = year
        nextYear = year + 1


    startDate = dt.date(nextYear, 1, 1)
    endDate = dt.date(nextYear, 12, 31)
    events = getEvents(calendar, startDate, endDate)
    events.sort(key=lambda x: x['start_dt'])
    statusID, valueID = customNameToID({'status': ['choices']})
    statusName, statusValues= customIDToName({statusID: ["choices"]})
    statusID, confirmID = customNameToID({'status': ['confirm'][0]})
    statusID, changeID = customNameToID({'status': ['change'][0]})
    statusID, pendID = customNameToID({'status' : ['pend'][0]})
    statusID, cancelID = customNameToID({'status' : ['cancel'][0]})
    names = {}
    events.sort(key=lambda events: events['who'])
    pcount = 0
    #print(startDate, endDate)
    errorList = list()
    for event in events:
        if event['rrule'].find('YEAR') == -1:
            continue
#        if event['who'] == "":
#            continue
#        if 'custom' not in event:
#            continue
#        if event['rrule'].find('WEEK') > -1:
#            continue
        if statusID not in event['custom']:
            msg = "No Custom Field found for " + fromTeamupDate(event['start_dt']) + " " + event['title']
            errorList.append(msg)
            continue
        status = event['custom'][statusID][0]
        if event['who'] not in names.keys():
            names.update({event['who']: { confirmID:0, changeID :0, cancelID: 0, pendID: 0}})
            #names.update({'name':event['who'], confirmID:0, changeID :0, pendID: 0})
        if status in (confirmID, changeID, pendID, cancelID):
            names[event['who']][status] +=1
            if status == pendID:
               pcount += 1
            #if status == cancelID:
               #print(event['who'])
    #print("rideID is ", rideID)
    if rideID == "vue":
        pending = {}
        for name,data in names.items():
            if data[pendID] == 0 and data[changeID] == 0:
                continue 

            pending.update({name: {'confirmed':data[confirmID], 
                                       'pending':data[pendID], 
                                       'cancelled':data[cancelID], 
                                       'change':data[changeID]}})
        return(json.dumps(pending))
    htmlHeader +=  """ <link rel="stylesheet
    href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script
    src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script
    src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script
    src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    """ 
    page = htmlHeader


    page += "  <body>  <div id='head' class='container-fluid' style='background:#c0fcf8; border:2px solid yellow'>  "
    page += " <div class='row'><div class=col> <br /></div></div>"
    page += " <div class='row'><div class=col-3>"
    page += " <form action='/mainMenu/mainMenu.php'>"
    page += "              <button class='btn btn-warning'"

    page += "                    >Back to Main Menu</button> </form> </div><div class=col-9> </div></div>"
    page += "<div class=row> <div class=col-5></div><h1>" + str(nextYear) + " New Year Reset<h1></div><div class=col-7></div>"


    page += "<div class=row><div class='col-6'>"
    page += """<label>When you reset the calender, it does two things. First
     all of the rides for last year will be disconnected from their repeating pattern, so changes made to future rides will no longer affect last years rides. Secondly, status for all rides for the new year will be set to Pending.

     """
    page += "</div>"

    page += "<div class='col-2'>"
######
#    if month > 3:
######
    page += " <input type='hidden'    name='cal' value='"
    page += calendar + "'  >  <input type='hidden'   name='nextYear' value="
    page += str(nextYear) + ">"
    if month > 2  or [pendID] in nested_lookup(statusID, events):
        disabled = "type= 'submit' disabled    style=' background-color: darkgrey; padding:15px;'>  LOCKED <br>  "
    else:
        disabled = "type = 'button' class='btn-3d red '   style='background-color: #aa0000; padding:15px;' > "

    url="'/resetNewYear?cal=" + calendar + "&nextYear=" + str(nextYear) + "'"
    url2="'/newYear?cal=" + calendar + "'"
    page +=  " <button  id='wait' onclick=\"setWait"
    page +=  url  + "," + url2 + ", 'wait' )\";" + disabled + " "
    page += " Reset Rides for "
    page += str(nextYear)+ " </button>    </div>"
    page += " <div class=col-4>"



    #print("pcount", pcount, "month", month )
    if month < 3  and pcount > 1 and pcount < 100:
        page += "<p style='background-color: darkred; color:white;padding:10px;'>"
        page += "The reset button only works if there are no Pending or Changes Pending rides for the new year. "
        page += "There are stil rides  with the status set to Pending or Changes Pending. You need to change these to Confirmed before the reset button will become activated."
        page += "  Click on the names"
        page += " below and search the Calendar for Pending and Changes Pending."
        page += " Change the status on those to Confirmed, and then refresh this page to continue."
        page += "When there are no Pending or Changes Pending rides in the new year, the reset button will become activated. Click it to change all rides in the new year from Confirmed to Pending. Then send email confirmation requests.</p>"
    else:

        page += "Note that the weekly rides are managed manually by the Rides Chair."
    page += """
</div>
<script>
function Waitand(wait) {
var x = document.getElementById(wait);
x.innerHTML= "<b>Please Wait...</b>";
x.type = "'submit' disabled";
x.style.color = 'white';
x.style.background ='darkred';
x.style.padding ='30px';
}
</script>
<script>
function setWait(url, url2, wait) {
    var xhttp;
    var x = document.getElementById(wait);
    x.type = "'submit' disabled";
    x.style.color = 'white';
    x.style.background ='darkred';
    x.style.padding ='30px';
    xhttp=new XMLHttpRequest();
    xhttp.open("GET", url, true);
    xhttp.send();
    xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        window.location.href= url;
                        xhttp.open("GET", url2, true);
                        xhttp.send();
                    }
                 };
}
</script>

    """
    msg = 'pending'
    page += "</div><div class=row> <div class=col-12 style='text-align:center;'><hr></hr></div></div>"
    page += "<div class=row> <div class=col-12 style='text-align:center;'> "
    page += "<h1>Ride Leader Email Messages</h1></div> <div>"
    page += """
    <div class=row><div class=col-3> </div>
<form>
<input type="radio" name="toggle" onclick="check(this.value)" value="pending" id=checked checked="checked">Request Confirmations for Pending Rides<br>
<input type="radio" name="toggle" onclick="check(this.value)" id=all value="all">Send a list all rides<br>
</form>
   <div class=col-8> </div></div>
    """
    page += "<div class=row> <div class='col-2'>"
    page += "<input type='hidden'  id='cal' value = '" + calendar +  "' />"
    page += """
    <button type="button" id="allNames" class="btn btn-primary" style="margin-top:00px;" > <!-- data-open="modal" data-target="#leaderModal"> -->
    Send to all Ride Leaders
    </button> </div>
    """
    page += "          <div class='col-4' id='allLabel'>"
    page += "</div> <div class=col-1>"
    page += "</div><div class='col-3' id='singleLabel'> </div>"

    page += "<div calss=col-1> "
#    page += " <button type='submit' id=all class='btn-3d yellow' "
#    page += "onclick=\"sendReminder('" + url + "');\"> Send</button>"
    page +="""
    </div> <div class=col-2><input type='text' class=form-control style='height:40px;'  id='rideLeader' name ='rideLeader' value=''  />
     <button type="button" id="name" style="margin-top:10px;  height:45px;"  class="btn btn-primary"  data-target="#leaderModal"> Send </button>
    """
    page += "</form></div></div>"
    page += """
<!-- Modal -->



<div class="modal fade" id="leaderModal" >  <!--  role="dialog" > -->
  <div class="modal-dialog modal-dialog-centered" > <!-- role="document"> -->
    <div class="modal-content" style='background: #669999; ' >
      <div class="modal-header">
        <h5 class="modal-title" id="title">Sending Email to... </h5>
      </div>
      <div class="modal-body"  id="leader-msg">
          Please wait...
      </div>
      <div class="modal-footer" visibility=visible; id=footer>
        <button type="button" class="btn btn-primary" id="continue">Continue</button>
        <button type="button" class="btn btn-danger" id="close">Cancel</button>
      </div>
    </div>
  </div>
</div>




<script>
    allConfirmMsg =  "After you've reset the Calender you should send Confirmation Request to all ride leaders. You can send these as often as you wish, as these will only go to Ride Leaders who still have not accepted all their rides for the new year.";
    singleConfirmMsg = "Send a Confirmation Request to just one Ride Leader by entering their name (must match the Ride Leader Table) and press Send.";

document.getElementById("singleLabel").innerHTML=singleConfirmMsg;
document.getElementById("allLabel").innerHTML=allConfirmMsg;

function check(toggle) {
    //alert("toggle is: " + toggle);
    if (toggle == "all") {
        document.getElementById("singleLabel").innerHTML="Send a List of all rides for this year to a single ride leader";
        document.getElementById("allLabel").innerHTML="Send a List of all rides for this year to all ride leader";
        }
    else {
      document.getElementById("singleLabel").innerHTML=singleConfirmMsg;
      document.getElementById("allLabel").innerHTML=allConfirmMsg;
      }
}

    document.getElementById('name').onclick = function () {
        document.getElementById("footer").visibility="visible";
        name = document.getElementById("rideLeader").value;
        if (name == "") {
            name = "Name Not Entered";
            }
        genRideLeaders(name);
    };
    document.getElementById('allNames').onclick = function () {
        genRideLeaders("all");
   };

    document.getElementById('close').onclick = function () {
        $("#leaderModal").modal('hide') ;
   };

    function genRideLeaders(name) {
        $("#leaderModal").modal('show') ;
        leaderMsg = document.getElementById("leader-msg");
        cal = document.getElementById("cal").value;

        rideStatus=$('input[name=toggle]:checked').val();
        //alert("rideStatus is:" + rideStatus);
        if (rideStatus == 'pending') {
             document.getElementById("title").innerHTML="Sending Only Pending Rides to:";
             }
        else {
             document.getElementById("title").innerHTML="Sending all Rides (Status set to Confirmed, Pending, or Changes Pending) to:";
             }
        if (name == "all" ) {
            url= "/getRideLeaderList?cal=" + cal + "&rideLeader=" + name + "&mode=" + rideStatus
            xhttp=new XMLHttpRequest();
            xhttp.open("GET", url, true);
            xhttp.send();
            xhttp.onload = function() {
                if (this.readyState == 4 && this.status == 200) {
                    leaderList =   JSON.parse(xhttp.responseText);
//                    document.getElementById("rideLeader").value = leaderList;
                    document.getElementById("leader-msg").innerHTML = leaderList;
                    document.getElementById("leader-msg").value = leaderList;
                    }
                else {
                    alert(`Error ${xhttp.status}: ${xhttp.statusText}`); // e.g. 404: Not Found
                    }
                };
          } else   {
               document.getElementById("leader-msg").innerHTML = name;
               document.getElementById("leader-msg").value = name;
          }
    };

    document.getElementById('continue').onclick = function sendEmails() {

       x = document.getElementById("leader-msg");
       cal = document.getElementById("cal").value;
       leaderList = encodeURI(document.getElementById("leader-msg").value);
      // alert(leaderList);
       rideStatus=$('input[name=toggle]:checked').val();
       x.innerHTML = "Sending email(s), <br>  Please wait...";
       document.getElementById("footer").visibility="hidden";
       url= "/summaryMail?cal=" + cal + "&rideLeader=" + leaderList + "&mode=sumaryMail&rideStatus=" + rideStatus + "&test=False"
//       alert(url);
       xhttp2=new XMLHttpRequest();
       xhttp2.open("GET", url, true);
       xhttp2.send();
       xhttp2.onload = function() {
             if (this.readyState == 4 && this.status == 200) {
                 x.innerHTML = "All mail sent";
                 $("#leaderModal").modal('hide');
             }
            else {
                alert(`Error ${xhttp2.status}: ${xhttp2.statusText}`); // e.g. 404: N Found
             }
       };
   };
check($('input[name=toggle]:checked').val());
</script>
    """
    page += "<div class='row'><div class=col style='text-align:center;'><HR></div></div></HR><div class=row>"
    page += " </div><div class='row'>"

    page += ""
    page += "              <div class='col-3 '></div>"
    page += ""
    page += "              <div class='col-2 colheading2'>"
    page += "              </div>"
    page += ""
    page += "              <div class='col-1 colheading2'"
    page += "                   style='border-bottom:None;'>"
    page += "                "
    page += "              </div>"
    page += ""
    page += "              <div class='col-1 colheading2'"
    page += "                   style='border-bottom:None;'>"
    page += "               "
    page += "              Changes</div>"
    page += ""
    page += "              <div class='col-1 colheading2'"
    page += "                   style='border-bottom:None;'>"
    page += "                "
    page += "              </div>"
    page += ""
    page += "              <div class='col-1 '></div>"
    page += ""
    page += "              </div><div class='row'>"
    page += ""
    page += "              <div class='col-3 '></div>"
    page += ""
    page += "              <div class='col-2 colheading2'>"
    page += str(nextYear) + " Ride"
    page += "                Leader"
    page += "              </div>"
    page += ""
    page += "              <div class='col-1 colheading2'"
    page += "                   style='border-bottom:None;'>"
    page += "                Confirmed"
    page += "              </div>"
    page += ""
    page += "              <div class='col-1 colheading2'"
    page += "                   style='border-bottom:None;'>"
    page += "                Pending"
    page += "              </div>"
    page += ""
    page += "              <div class='col-1 colheading2'"
    page += "                   style='border-bottom:None;'>"
    page += "                Pending"
    page += "              </div>"
    page += ""
    page += "              <div class='col-1 '></div>"
    page += "                </div><div class='row'>"
    for rideLeader, statusList  in names.items():
        if statusList[pendID] == 0 and statusList[changeID] == 0:
            continue
        page += "              <div class='col-3 '> </div>"
        page +=  " <div class='col-2 namecol'>"
        page += "<a href='https://teamup.com/" + calendar + "?keywords=&quot;" + quote_plus(rideLeader)
        page += "&quot;&view=a&showAgendaDateRange=year&title=Rides%20For%20" + quote_plus(rideLeader) + "'"
        page +=   quote_plus(rideLeader) + ", >" + rideLeader + " </a>"
        page +=  "</div>"

        for key, value, in statusList.items():
            page +=  " <div class='col-1 tbl-body'> " + str(value) + "</div>"
        page += "              <div class='col-1 '> </div>"
        page +=  "   </div><div class='row'>"
    page += "</div><div class='row'><div class=col style='text-align:center;'><br/> </div></HR><div class=row>"
    page += "</div>"
    page += "</body>"
    page += "</html>"
    page += ""




    if __name__ == "__main__":
        print(page)
    else:
        return(page)

def main(argv):

    calendar = ""
    try:
        opts, args = getopt.gnu_getopt(argv, "")
    except getopt.GetoptError:
        print (argv[0], ' [calendar]')
        sys.exit(2)
    argCount = 0
    for opt, arg in opts:
        if  arg == '':
            argCount += 1
        else:
            argCount += 2
    if len(argv) > 0:
        calendar = argv[0]

    if calendar == "":
        calendar = calendarPicker("new year")
    newYear(calendar)

if __name__ == "__main__":
    main(sys.argv[1:])


