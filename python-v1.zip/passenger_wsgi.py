import imp
import os
import sys

#print("passenge", __file__)
sys.path.insert(0, os.path.dirname(__file__))

#wsgi = imp.load_source('wsgi', '/home/jay/ebc/msgBroker.py')
wsgi = imp.load_source('wsgi', '/var/www/ebc/msgBroker.py')
application = wsgi.msgBroker
