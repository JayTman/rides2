from teamup import *

from saveMsg import *
import wingdbstub
from rideReport import genReport, getRideList
from urllib.parse import unquote, quote_plus, parse_qsl
import requests
from reloadTestCalendar import *
def msgBroker(environ, start_response):

    wingdbstub.Ensure()
    print("hello2")
    status = "200 OK"
    headers = [('Content-Type', 'text/html')]
    start_response(status, headers)

    path=environ['PATH_INFO']
    rawArgs=environ['QUERY_STRING']
    args= parse_qsl(rawArgs)
    response = str()
    print("REQUEST", environ['REQUEST_METHOD'])
    path = path.replace("\W", "")
    if len(path) > 1:
        if path[0] == "/":
            path=path[1:]
        if path[-1] == "/":
            path = path[:-1]
    msgID=None
    msg="None"
    rideLeader=""
    rideID = False
    calendar = ""
    for arg in args:
        if len(arg[1]) > 0:
            argNoWhitespace = arg[1].replace('\W', '')

        if arg[0] == 'msgID':
            msgID=argNoWhitespace
        if arg[0] == 'cal':
            cal = argNoWhitespace
        elif arg[0] == 'rideID':
            rideID=argNoWhitespace
        elif arg[0] == 'id':
            id=argNoWhitespace
        elif arg[0] == 'filename':
           filename=argNoWhitespace
        elif arg[0] == 'rideLeader':
            rideLeader=argNoWhitespace
        elif arg[0] == 'who':
            rideLeader=argNoWhitespace
        elif arg[0] == 'msg':
            msg=argNoWhitespace
        elif arg[0] == 'rideStatus':
            rideStatus=argNoWhitespace
        elif arg[0] == 'test':
            if argNoWhitespace == "False":
                test=False
            else:
                test=True   
        else:
            function='invalid argument'

##        if path == 'msgBroker':
##            function=msgID
##        else:
    function=path

    print("TIME 0 ", timestamp(), "function ", function, "args",  args, "cal", calendar)
        #add calendar
###           if function.find("images") > -1:
###               response = ""
###               print("at ", function);
###               return [response]

    if function in ("monthBeforeReport"):
        initCustomDef(cal)
        rideStatus="None"
        #getCustomDefs()
        genReport("monthBefore.msg", cal, rideLeader, rideStatus)
        genReport("leaderNeeded.msg",cal, rideLeader, rideStatus)
        #sendReport(function, cal, rideLeader, rideList, rideStatus)
        response="Emails sent."
    elif function in ("monthBefore.msg", "leaderNeeded.msg"):
            initCustomDef(cal)
            rideStatus="None"
            #getCustomDefs()
            genReport(function ,cal, rideLeader, rideStatus, test)
            #sendReport(function, cal, rideLeader, rideList, rideStatus)
            response="Emails sent."
###           elif function in ("upload"):
###               content_length = int(self.headers['Content-Length']) # <--- Gets the size of data
###               post_data = self.rfile.read(content_length) # <--- Gets the data itself
###               logging.info("POST request,\nPath: %s\nHeaders:\n%s\n\nBody:\n%s\n",str(self.path), str(self.headers), post_data.decode('utf-8'))
###               self._set_response()
###               self.wfile.write("POST request for {}".format(self.path).encode('utf-8'))
                 
    elif function in ("pendingRides.msg", "allRides.msg", "newYear.msg"):
        initCustomDef(cal)
        leaderList = unquote(json.dumps(rideLeader)).replace('"','')
        if leaderList.find(",") > -1:
            leaderList = leaderList.split(',')
            for rideLeader in leaderList:
                genReport(function, cal, rideLeader.strip(), rideStatus, test)
        else:
            rideLeader = leaderList
            genReport(function, cal, rideLeader, rideStatus, test)
        response="Emails sent."
        return [response.encode()]

    elif function =="processImage" :
        response=processImage(msg, id, filename)
        if not isinstance(response, str):
            response = json.loads(response)
    elif function =="getPictures" :
        response=getPictures(id)
    elif function =="saveMsg" :
        response=saveMsg(cal, msgID, filename, msg, rideStatus)

    elif function =="getfile" :
        file = dataDir + msg
        with open(file, 'r') as reader:
            response=reader.read()
            reader.close()
###           elif function =="rmfile" :
###               response=rmFile(filename)
    elif function =="readFile" :
        response=readFile(filename)
    elif function =="savefile" :
        response=saveFile(filename)
    elif function =="renamefile" :
        response=renameFile(id, filename,  msg)
    elif function =="newYearCheck" :
        response=newYearCheck(filename, id, msg)

###           elif function =="getRides" :
###               response=getRides(cal, rideStatus, rideLeader)
    elif function =="getRideLeaderInfo":
        response=getRideLeaderInfo()
    elif function =="putRideLeaderInfo":
        response= putRideLeaderInfo(msg)
        
    elif function =="rideChangeMsg":
        email(msg, rideLeader, ridesChair, "ride change from " + rideLeader + ".");
        response= "email sent"
    elif function == 'reloadTestCalendar':
        reloadTestCalendar(cal, msg, True)
        response = "Completed from Server"
    elif function == 'newRide':
        response = "<script> window.location.href='newRide/index.html';  </script>"

    #
    # error conditons
    #

    elif function == "testme":
        response = 'Request method: %s' % environ['REQUEST_METHOD']
        for x in environ:
            response += "<b>" + str(x) + ":</b> "
            response += str(environ[x])  + "<br>"
    elif function == "/":
        print("<h2>"   "</h2>")
        file = webDir + "/matrix.php"
        with open(file, 'r') as reader:
            response=reader.read()
    else:
        response = """
   <html><br /> <br /><h1><em><strong>Sorry,
   <img src="https://ebcrides.org/browser/upload/oops.jpg"
   style="float: left;" />, Something's gone wrong.</strong></em></h1>
   <p><strong></html>
        """
        response +="<h4> The action causing the problem is: " + str(function) + "<br /> The parameters are: " + str(args)
        status = '595'
    print(" TIME 8 ", timestamp())

    if response:
        return [response.encode()]
    else:
        return("")
