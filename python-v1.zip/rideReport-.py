# -*- coding: utf-8 -*-

from teamup import *
from dateutil.relativedelta import relativedelta
from urllib.parse import quote_plus
from urllib.parse import quote

def genReport(reportFile, cal, rideLeader, reportStatus='pending', test=False):
    count = 0
    reportBody = ""
    statusID, confirmID = customNameToID({'Status': ['Confirmed']})
    statusID, pendID = customNameToID({'Status': ['Pending']})
    statusID, leaderNeededID = customNameToID({'Status': ['Need']})
    statusID, changeID = customNameToID({'Status': ['Change']})
    calendars = getSubCalendars(cal)
    rides = []
    report = ""
    today = dt.date.today()
    rides = getRideList(reportFile, cal, rides, test)

    for ride in rides:
        # for these reports there's no ride leader to test for
        if reportFile in ("monthBefore.msg", "leaderNeeded.msg"):
            rideLeader = ride['who']        
        match = rideLeaderMatch(rideLeader, ride, calendars)
        if match != rideLeader:
            continue
        if 'custom' in ride:
            if statusID in ride['custom']:
                rideStatus = ride['custom'][statusID]
                
        if reportFile in ("pendingRides.msg"):
            if rideStatus == confirmID:
                continue
                
        # send reminder email to the rideLeader 1 month before the ride's date
        if reportFile in ("monthBefore.msg"):
            if rideStatus != confirmID:
                continue

            #
            # this will suppress reminders from going everyday for multi day
            # rides. It will just be sent on the first day.
            #
            p = parse(ride['start_dt'])
            sdate = dt.datetime.strftime(p, '%m/%d/%Y')
            p = parse(ride['end_dt'])
            edate = dt.datetime.strftime(p, '%m/%d/%Y')
            oneMonthFromToday = dt.datetime.strftime(p, '%m/%d/%Y')
            #if test == False:
                #if sdate != edate and sdate != oneMonthFromToday:
                    #continue
                #rideLeader = ""
                #rideDesc = ""
            report += monthBeforeReport(ride)
            sendReport(reportFile, cal, ride['who'], report, reportStatus)
            return

        elif reportFile in ("leaderNeeded.msg"):
            if rideStatus != leaderNeededID:
                continue
            rides = []
            report += monthBeforeReport(ride)
            rideLeaders = getRideLeaderList(cal, rides, ride['subcalendar_id'])
            for leader in rideLeaders:
                if test == True:
                    break
                sendReport(reportFile, cal, leader, report, reportStatus)
            ridesChairMsg = "<h3> Ride leader needed emails were sent to: <br /> " + str(rideLeaders)
            ridesChairMsg +="<br /> for this ride.</h3>"
            ridesChairMsg = ridesChairMsg.replace('[', '')
            ridesChairMsg = ridesChairMsg.replace(']', '')
            ridesChairMsg += report                
            email(ridesChairMsg, 'ridesChair', 'ridesChair', "A Ride on " + fromTeamupDate(ride['start_dt']) + " needs a ride leader.")
            return
        
        elif reportFile in ("pendingRides.msg", "allRides.msg", "newYear.msg"):
            report += rideListReport(ride, confirmID, statusID)
    sendReport(reportFile, cal, rideLeader, report, reportStatus)                    
    response="sent"

        


def monthBeforeReport(ride):
    p = parse(ride['start_dt'])
    sdate = dt.datetime.strftime(p, '%m/%d/%Y')
    p = parse(ride['end_dt'])
    edate = dt.datetime.strftime(p, '%m/%d/%Y')
    p = parse(ride['start_dt'])
    oneMonthFromToday = dt.datetime.strftime(p, '%m/%d/%Y')
    #
    # this will suppress reminders from going everyday for multi day
    # rides. It will just be sent on the first day.
    #
    if sdate != edate and sdate != oneMonthFromToday:
        return

    date = fromTeamupDate(ride['start_dt'])
    #if reportFile in ("monthBefore.msg", "leaderNeeded.msg"):
    reportBody =""
    reportBody += "<h2>"
    reportBody += date + " " + ride['title']
    reportBody += "</h2>"

    reportBody += "<p>Start Location: " + ride['location']
    reportBody += "<br />Leader: " + ride['who'] + "<br />"

    #
    # get the custum fields and convert them from ID numbers
    # to their names and add them to the report
    #
    custom = ""
    reportBody += getCustomFields(ride['custom'], custom)
    reportBody += "<p> </p>"
    # 
    # If it exist, add ride description to the reprt
    #
    if ride['notes'] != None and ride['notes'] != "":
        reportBody += "<small>" + ride['notes'] + "</small></p>"

    # convert from ID to Labels *
    if 'custom' in ride:
        for k, v in ride['custom'].items():
            if k.find("Status") > -1 and v.find("Confirm") == -1:
                email(reportBody, 'ridesChair', 'ridesChair', "This upcoming ride hasn't been confirmed yet")
    return(reportBody)



def rideListReport(ride, confirmID, statusID):
    reportBody = ""
    date = fromTeamupDate(ride['start_dt'])
    reportBody += date + " " + ride['title']
    if ride['custom'][statusID] != confirmID:
        reportBody += " (unconfirmed)"
    reportBody += "<br />"
    return(reportBody)



def sendReport(reportFile, calendar, rideLeader, reportBody, reportStatus):
    # If report lenght is zere, then nothing to send. 
    if len(reportBody) == 0:
        return("")

    today = dt.date.today()
    if today.month < 7:
        rideYear = str(today.year)
    else:
        rideYear = str(today.year + 1)

    file = open(dataDir + reportFile, "r")
    msg = file.read()
    file.close()
    today = dt.date.today()
    rideDate = str(today + relativedelta(weeks=+4))
    rideButton = ""
    if reportFile in ("pendingRides.msg", "allRides.msg", "newYear.msg"):
        #rideButton = "<div><p><a href='http://localhost:8080/RideReview/"
        #rideButton += quote(rideLeader) + "/all'>"
        #rideButton += "<img src=https://ebcrides.org/images/cal/button_review_rides.png </a></p></div>"
        rideButton ="<div><a href='" + webServer + "RideReview/"
        rideButton += quote(rideLeader) + "/all'>"
        rideButton += "<button class='btn'>Review Rides</button> </a></div>"
        rideButton += "<style>  .btn {  background-color:  #154c81; color:white;  padding: 10px 24px; "
        rideButton += "font-size: 12px;  display: inline-block; text-decoration: none; } "
        rideButton += ".btn:hover {background:  #88aed1 ; padding: 10px 24px; } </style> </html>"
        #rideButton += " .desc {  background: #FFE082; color:black;  
        calButton ="<a href='https://teamup.com/" + calendar + "?query=" + quote(rideLeader) + "' >"
        calButton += "<button class='btn'>Calendar Rides</button></a> </div>"
        calButton += "<style>  .btn {  background-color:  #154c81; color:white;  padding: 10px 24px; "
        calButton += "font-size: 12px;  display: inline-block; text-decoration: none; } "
        calButton += ".btn:hover {background:  #88aed1 ; padding: 10px 24px; } </style> </html>"


    print("Replacing");
    p = parse(rideDate)
    rideYear = dt.datetime.strftime(p, '%Y')
    msg = msg.replace("@RideLeader", rideLeader.split()[0])
    msg = msg.replace("@RideList", reportBody)
    msg = msg.replace("@RideButton", rideButton)
    msg = msg.replace("@RideDate", rideDate)
    msg = msg.replace("@RideButton", rideButton)
    msg = msg.replace("@CalendarButton", calButton)

    #HTMLHeader += "<div  class='box card remindercard' >" 

    report = msg
    
    subject="None"
    if reportFile in ("monthBefore.msg"):
        subject = "Reminder: upcoming EBC ride on " + rideDate
    elif reportFile in ("leaderNeeded.msg"):
        subject = "A ride on " + fromTeamupDate(rideDate) + " needs a ride leader"
    elif reportStatus == 'pending':
        subject= "You have pending rides for "  + rideYear
    elif reportStatus == 'newYear':
        subject= "Please confirm that ayou can lead these rides in "  + rideYear
    else:
        subject= "Your EBC Scheduled Rides for "  + rideYear

    email(report, 'ridesChair', rideLeader, subject)
    return("<h3>sent</h3>")

def getCustomFields(rawCustom, displayCustom):
    for keyID, valueID in rawCustom.items():
        key, val = customIDToName({keyID: valueID})
        if isinstance(val, list):
            values = ""
            for i in range(len(val)):
                values += str(val[i]) + " "
        else:
            values = str(val)
        displayCustom += key + values + "<br />"
    return(displayCustom)

def getStartDate(reportFile):
    today = dt.date.today()
    if reportFile in ("monthBefore.msg", "leaderNeeded.msg"):
        startDate = today + relativedelta(months=+1, minutes=+1)
    else:
        if today.month > 10:
            year = today.year + 1
        else:
            year = today.year
        startDate = dt.date(year, 1, 1)
    return(startDate)

def rideLeaderMatch(rideLeader, ride, calendars):
    #
    # SKIP a bunch of stuff
    if ride['who'] ==  "":
        #print("RET" +ride['who'] + " S " + ride['start_dt'] + " " + ride['title'])
        ret = False
        return ret
        #continue
    # skip weekly rides
    if ride['rrule'].find('WEEKLY') >= 0:
        #print("False match weekly" +ride['who'] + " " + ride['start_dt'] + " " + ride['title'])
        ret = False
        return ret
        #continue

    names = subCalIDToName(calendars, ride['subcalendar_id'])
    if 'Meeting' in names:
        #print("False match meeting " + ride['who'] + " " + ride['start_dt'] + " " + ride['title'])
        ret = False
        return ret
        #continue

    #
    # if testing  rideLeader will be empty so
    # set rideLeader to the first ride  not being skipped 
    #
    if rideLeader == "":
        rideLeader = ride['who']

    # check to see if the ride is for the requested rideLeader
    if ride['who'].lower().find(rideLeader.lower()) > -1:
        print("ride leader match" + ride['who'] + "  " + ride['start_dt'] + " " + ride['title'])
        return rideLeader            
            #continueZNZ
    # if no match on the ride['who'] check to see if there's a
    # second ride leader by looking for a '/'



def getRideLeaderList(calendar, rides, subcalendar_id):
    rides = getRideList("allRides.msg", calendar, rides)
    leaderlist = []
    for ride in rides:
        if ride['who'] == "":
             continue
###        if ride['who'].split("&")[0].strip() in leaderlist:
###            continue
        # this means that you're only looking for rideLeaders that have rides
        if ride['subcalendar_id'] == "":
            leaderlist.append(ride['who'].strip());
            ###                leaderlist.append(ride['who'].split("&")[0].strip());
        elif subcalendar_id in ride['subcalendar_ids']:
            if ride['who'].strip() not in leaderlist:
                leaderlist.append(ride['who'].strip());
                ###                leaderlist.append(ride['who'].split("&")[0].strip());
    return(leaderlist)

def getRideList( reportFile, calendar, rides, test = False):
    #figure out which date(s) to run
    #he reportaa. If in Dec, run for next year.
    today = dt.date.today()
    if today.month > 10:
        startYear = today.year + 1
    else:
        startYear = today.year
    startDate = dt.date(startYear, 1, 1)
    endDate = dt.date(startYear, 12, 31)
#    if reportFile in ("pendingRides.msg", "allRides.msg", "newYear.msg"):
    today = dt.date.today()
    
    if reportFile in ("monthBefore.msg", "leaderNeeded.msg" ):
        startDate=today+ relativedelta(weeks=+4)
        if test == False:
            endDate = startDate + relativedelta(hours=+23, minutes=+58)
        else:
            endDate = startDate + relativedelta(months=+11)

    config = getConfig(calendar)
    calendars = getSubCalendars(calendar)
    rides = getEvents(calendar, startDate, endDate)
    rides.sort(key=lambda rides: rides['who'])
    statusID, confirmID = customNameToID({'Status': ['Confirmed']})
    statusID, pendID = customNameToID({'Status': ['Pend']})
    statusID, leaderNeededID = customNameToID({'Status': ['Need']})
    if test == False:
        return(rides)
    elif test == True:
        #
        # find the first confirmed ride
        #
		        
        if reportFile != "monthBefore.msg" and reportFile != "leaderNeeded.msg":
            return(rides)
        for ride in rides:
            names = subCalIDToName(calendars, ride['subcalendar_id'])
            if 'Meeting' in names:
               continue
            if ride['who'] == "":
               continue
            if ride['rrule'].find('YEAR') > -1:
                if reportFile == "monthBefore.msg" and \
                   ride['custom'][statusID] == confirmID: 
                    return([ride])
                elif reportFile == "leaderNeeded.msg":
                    if ride['custom'][statusID] == pendID or \
                       ride['custom'][statusID] == leaderNeededID:                        
                       return([ride])
    return(rides)
    breakPoint="here"








    # Add to google or iCalendar buttons
    #
    #def reminderReportButtons(calendar, ride):
        #buttons = ""
        ## get time and date into format that google likes
        #p= parse(ride['start_dt'])
        #tz = dt.datetime.strftime(p, '%z')
        #if tz == "":
            #tz = 0
        #else:
            #tz = int(dt.datetime.strftime(p, '%z')[:3])
    
        #p = p - relativedelta(hours=+tz)
        #sdate = dt.datetime.strftime(p,'%Y%m%dT%H%M00Z')
        #p= parse(ride['end_dt'])
        #p = p - relativedelta(hours=+tz)
        #edate = dt.datetime.strftime(p,'%Y%m%dT%H%M00Z')
        #gcal = "https://calendar.google.com/calendar/r/eventedit?sprop=website:www.teamup.com"
        #gcal += "&text=" + quote_plus(str(ride['title'])) + "&dates=" + sdate + "/"
        #gcal += edate
        #gcal += "&location=" + quote_plus(str(ride['location'])) + "&details=" + quote(str(ride['notes']))
        #gcal += "a&sf=True"
    
    
        #googleButton = "<div style=-wrap:wrap;><a href='" + gcal + "' target='_blank' rel='noreferrer noopener external' style=margin-left:5px>"
        #googleButton += "<img src='https://ebcrides.org/images/cal/google-calendar.png' alt=''></a>"
    
        #iCalButton = "<a href='https://teamup.com/" + calendar + "/events/" + ride['id'] + ".ics' download='EBC_Ride'>"
        #iCalButton += "<img src='https://ebcrides.org/images/cal/icalendar.png' alt='' style=margin-left:55px;></a>"
    
    
        #buttons += "<h6 style=text-align:left>Press the button below to add this to your personal calendar</h6><br>" + googleButton + iCalButton
        #return(buttons)
    
