from teamup import *
import sys
from dateutil.parser import parse
import copy
from collections import defaultdict
from nested_lookup import nested_update, nested_delete, nested_lookup, get_occurrence_of_key, get_occurrence_of_value, get_all_keys

# Calendar ID's
insertRides = True
findRides = False

def deleteCustomsFields(toCal):
    params = ""
    fields = getFields(toCal)
    for field in fields:
        if field['type'].find('builtin') > -1:
            continue
        print(field['id'])
        results = queryTeamup(PASSW_HEADERS, toCal, 'delete', 'field-definitions', params, field['id'])
        if isinstance(results, str):
            print(results)
            return(results)



def restoreRides(fileName, toCal):
    calName = ""
    if insertRides == False:
        print("Running in test mode, nothing will get altered")
    #teamupCal = calendarPicker("Pick a Calendar to restore ")

    if insertRides == False:
        print ("Testing ")
    else:
        print ("Restoring ")

    if fileName == "":
        fileName = filePicker("Pick one: ", "*.jsn")
    if toCal == "":
        toCal = calendarPicker("Pick a calendar to restore into: ")


    with open(fileName, "r") as results:
        fileCal = json.load(results)
    initCustomDef(toCal)

    toConfig = getConfig(toCal)
    fileConfigs = fileCal['configuration']
    fileSubCalendars = fileCal['subcalendars']
    fileRides = fileCal['events']
    fileRides.sort(key=lambda x: x['start_dt'])
    fileCustomDef = fileConfigs['fields']['definitions']
    start = parse(fileRides[0]['start_dt'])
    start  = dt.date(start.year, start.month, start.day)
    end = fileRides[-1]['start_dt']

    initCustomDef(toCal)
    toSubCalendars = getSubCalendars(toCal)
    toConfig = getConfig(toCal)
    toEvents = getEvents(toCal, start, end)
    toEvents.sort(key=lambda x: x['start_dt'])
    count = 0    
    errorCount = 0
    updateCount = 0   
    errors = ""
    tmp = copy.deepcopy(fileCustomDef)
    initCustomDef(toCal)
    createCustomFields(toCal, tmp)
    fileStatusID, valueID = customNameToID({'status': ['choices']}, fileCustomDef)
    toStatusID, valueID = customNameToID({'status': ['choices']})
    for fileEvent in fileRides:
        date = fromTeamupDate(fileEvent['start_dt'])
        month = date[0:2]
        rideName = "Processing:" + date + " " + fileEvent['title']
        print(rideName)
        if 'custom' not in fileEvent:
            continue
#        print(fileEvent['custom'])
        if fileStatusID not in fileEvent['custom']:
            continue
        fcustom = fileEvent.pop('custom')
        newCustom = dict()
        
        for fieldID, valueID in fcustom.items():
            fieldName, valueName = customIDToName({fieldID: valueID}, fileCustomDef)
            toFieldID, toValueID = customNameToID({fieldName:valueName})
            if toFieldID == None or toFieldID == 'notfound':
                continue
            newCustom.update({toFieldID:toValueID})
        fileEvent['custom'] = newCustom

        if fileEvent['series_id'] == None:
            print("Warning: Event does not repeat, no series id set ")

        restoreSubCals(toSubCalendars, fileEvent)
        print(fileEvent['series_id'], " ", fileEvent['rrule'])
        skip = False
        updated = False
        for toEvent in toEvents:
            if toEvent['title'] == fileEvent['title'] \
               and toEvent['start_dt'] == fileEvent['start_dt'] \
               and toEvent['who'] == fileEvent['who']:
                updated += 1
                #any changes go here
                print("toEvent ", toEvent['custom'] , "\nnewsting ", fileEvent['custom'])
                toEvent['custom'] = fileEvent['custom']
                # do not remove redit
                toEvent['redit'] = "all"
                updateEvent(toCal, toEvent)
                updated = True
                print("Updated.")
                updateCount += 1
                break

            else:
                continue
        if updated == True:
            updated = False
            continue
        params = ""
        fileEvent['redit'] = "all"
        res = queryTeamup(UPDATE_HEADERS, toCal,
                         'post', 'events', params, fileEvent)
        if isinstance(res, str):
            if res.find("Er") > -1:
                errors += rideName + " " + res + "\n"
                errorCount += 1
            print(res)
        else:
            print("Inserted.")

            count += 1
    print("\n\n", errors)
    print("\nRestore Complete: Inserted " + str(count) + " Updated: " + str(updateCount) + " Errors: "  + str(errorCount))

def main(argv):
    global insertRides
    fileName = ""
    if len(argv) < 2:
       restoreRides("", "")
    else:
       restoreRides(argv[0], argv[1])

if __name__ == "__main__":
    main(sys.argv[1:])


