from teamup import *
import os
import fnmatch
import urllib
import os.path
import random
from csv import reader
from wand.image import Image
from wand.display import display
from rideReport import *
from urllib.parse import unquote, quote_plus, quote

def newYearCheck(fileName, mode, msg):
    fullPath = dataDir + fileName
    if mode == "READ":
        print("at")
        if os.path.isfile(fullPath): 

            msg = readMsgFile(fullPath)
        else:
            today = dt.date.today()
            year = today.year
            month = today.month
            day = today.day
            msg = str(year) + str(month) + str(day)
            saveMsgFile(fullPath, msg)
            msg = readMsgFile(fullPath)
    if mode == "WRITE":    
        saveMsgFile(fullPath, msg)
        msg = readMsgFile(fullPath)
    return(json.dumps(msg))

def saveMsgFile(fullPath, msg ):
    file =  open(fullPath , 'w')
    file.write(msg)
    file.close()

def readMsgFile(fullPath ):
    if not os.path.isfile(fullPath): 
        msg = "The file " + fullPath + " was not found"
        return(msg)
    file =  open(fullPath , 'r')
    msg = file.read()
    file.close()
    return(msg)

def  saveMsg(cal, msgID, fileName , msg, rideStatus):
    path = dataDir + fileName
    suffix = "-save"


    if msgID == 'save':
        saveMsgFile(path, msg)
    elif msgID == 'install':
        saveMsgFile(path, msg)
        saveMsgFile(path + suffix, msg)
    elif msgID == 'revert':
        if os.path.isfile(path + suffix): 
            msg = readMsgFile(path + suffix)
        else:
            print("Error, backup file doesn't exist: ", path + suffix)
        saveMsgFile(path, msg)
    elif msgID == 'test':
        saveMsgFile(path, msg)
        rides = []
        rideLeader = ""
        test=True
        #if  fileName .find( "remind") > -1:
            #function = "reminderMail" # reminder
            #rideStatus="confirmed"
        #elif  fileName .find( "all") > -1: # new year
            #function = "summaryMail"
            #rideStatus="all"
        #elif  fileName .find( "confirm") > -1: # confirm
            #function = "summaryMail"
            #rideStatus="pending"
        #else:
            #response = "INVALID File Name"
        ##if  fileName .find("List") > -1:
        ##    rideStatus="all"
        rides = []
        initCustomDef(cal)
        genReport(fileName, cal, rideLeader, rideStatus, test)


#def  getRides(cal, rideStatus, rideLeader = ""):
    #rides = []
    #rideList = []
    #test = False
    #initCustomDef(cal)
    #defs = getCustomDefs()
    #statusID, valueID = customNameToID({'status': ['choices']})
    #statusName, statusValues= customIDToName({statusID: ["choices"]})
    #statusID, confirmID = customNameToID({'status': ['confirm'][0]})
    #statusID, changeID = customNameToID({'status': ['change'][0]})
    #statusID, pendID = customNameToID({'status' : ['pend'][0]})
    #statusID, cancelID = customNameToID({'status' : ['cancel'][0]})
    #calendars = getSubCalendars(cal)
    #rides = getRideList( "summaryMail", cal, test)
    #for ride in rides:

        ## skip meetings
        ##
        #names = subCalIDToName(calendars, ride['subcalendar_id'])
        #if 'Meeting' in names:
           #continue

        ## skip rides without leaders
        #if ride['who'] ==  "":
            #continue

        ## skip rides without a status field 
        #if 'custom' not in ride:
            #print("custom not found in ride \n")
            #continue
        #if  statusID not in ride['custom']:
            #print("status not found in ride\n")
            #continue

        ## skip Weekly rides
        #if ride['rrule'].find('WEEK') >  -1:
            #continue

        ## Skip this ride if it's not for the passed in rideLeader
        ## or co rideleader
        ##  
        ## don't look for a match if testing
        #if test == False:
            ##  don't look for a match if processing all ride leaders
            #if rideLeader != "all":
                ##NEW LOGIC
                ## Now check to see if there  is a co-ride leader
                ##   which is a '/' in rideLeader field of the ride
                #index  = ride['who'].find('/')
                #if index == -1:
                    ## only one ride leader definded for the ride.
                    ## if no match against the passed in ride leader name skip                  
                    #if (ride['who']).lower() != rideLeader.lower():
                       ##print("!"+ ride['who'].lower()+ "!"+ rideLeader.lower()+ "!")
                       #continue
 
                 ##   check both names and see if either is 
                 ##   a match against the passed in ride leader name
                 ##   if neither match skip 
          ###      elif ride['who'][0].lower().find(rideLeader.lower()) == -1 \
            ###        and ride['who'][:index-1].lower().find(rideLeader.lower()) == -1:
              ###       continue
                 ###
                 ### OLD LOGIC
                 ###if ride['who'].find('/') > -1:
                     ###i  = ride['who'].find('/') - 1 
                 ###else:
                     ###i = len(ride['who'])
                     #### check for a match for the ride leader before the "/"
                 ###if ride['who'][:i].lower().find(rideLeader.lower()) == -1:
                     ###continue
                 ###                 


                 ####                  
        ####                         elif ride['who'][0].lower()  > rideLeader[0].lower():
        ####                             break
        ####                 

 
        ##
        ## Now have a ride that matches the criteria passed in
        ## Either a positive match (rideLeader matches, or 
        ## looking for all ride leaders or testing

        ##
        ## if only looking for pending rides, skip if confirmed
        #if rideStatus == "pending":       
            #if ride['custom'][statusID][0] == confirmID:
##               ride['custom'][statusID][0] != changeID:
                ##print(ride['custom'][statusID][0] + " " +  changeID + " " + confirmID)
                #continue;
        ## add a field with the status as a readaable name, not the ID
        ## cappitaize  the field name to differenciate it
        #key, val = customIDToName(ride['custom'])
        #ride.update({key.capitalize() : val[0]})
        
        ##if ride['custom'][statusID][0] == PendID:
            ##ride.update({"Status":"Pending"})
        ##elif ride['custom'][statusID][0] == changeID:
            ##ride.update({"Status":"Changes Pending"})
        ##elif ride['custom'][statusID][0] == confirmID:
            ##ride.update({"Status":"Confirmed"})
        ##elif ride['custom'][statusID][0] == cancelID:
            ##ride.update({"Status":"Cancelled"})

        ## do the same for the other custom fields, add a field
        ## with the names instead of  IDs 
        #for keyID, valueID in ride['custom'].items():
            #key, val = customIDToName({keyID: valueID})
            #if isinstance(val, list):
                #rideDetails = ""
                #for i in range(len(val)):
                    #rideDetails = str(val[i]) + " "
                    #ride.update({key.capitalize() : rideDetails})

            #else:  
                #rideDetails = str(val)
                #ride.update({keyID.capitalize() : rideDetails})

        #date = fromTeamupDate(ride['start_dt'])
        #ndate = date[6:10] + "/" + date[0:5] + " " + date[11:]
        #ride.update({"Date": ndate})
        #ride.update({"Frequency" : ride['rrule'][0:15] })
        ##coLeaderPaceID, x = customNameToID({'Co Leader Pace' : None})
        #rideList.append(ride)                


    #return(json.dumps(rideList))

def getPictures(imageDir):              
    fileList = []
    id = 0
    path = webDir + imageDir
    
    for fileName in os.listdir(path):
        if fileName.lower().find("jpg") == -1:
            continue
        filePath = os.path.join(path, fileName)
        if os.path.isfile(filePath) == False:
            return("Error: The file " + filePath + " could not be opened.")
    
        with Image(filename=filePath) as img:
            (width, height) = img.size
            img = "<img src='" + webServer + imageDir + fileName + "'>" #new
            #img2 = imageServer + fileName #new
            fileName = fileName.rsplit(".", 1)[0];
            
            fileList.append({'id': id , 'title' : fileName, 'oldName' : fileName, \
              #      'img' :img, 'img2' : img2, 'width': width, 'height' : height})
               'img' :'', 'img2' : '', 'width': width, 'height' : height})            
    fileList.sort(key=lambda fileList: (fileList['title'].lower()))
    id=0
    for f in fileList:
        f['id'] = id
        id += 1;
    return(json.dumps(fileList))

def processImage(func, imageDir, file):  
#    import webbrowser
    path = os.path.join(webDir + imageDir, file + ".jpg")
    if os.path.isfile(path) == False:
        print("Error: The file " + path + " could not be opened.")
        return("Error: The file " + path + " could not be opened.")

    with Image(filename=path) as img:
        if func == "delete": 
            i= os.unlink(path)
            if i != -1:
                return(json.dumps("Success"))
            else:
                return(jason.dumps("Failure"))
        elif func in ( "rotateR", "rotateL"):
          # Invoke rotate functiaon []]
            with img.clone() as rotated:
                (width, height) = img.size
                if func == 'rotateR': 
                    degrees = 90
                else:
                    degrees = 270
                img.rotate(degrees,'white', True)
                (width, height) = img.size
                img.save(filename=path)
                return(json.dumps({'width':width,'height': height}))
                
        elif func == "darker":
            img.level(gamma=0.7)
            (width, height) = img.size
            img.save(filename=path)
        elif func == "lighter":
            img.level(gamma=1.6)
            (width, height) = img.size
            img.save(filename=path)

        elif func == "getSize":
            (width, height) = img.size  
            return(json.dumps({'width':width,'height': height}))
        elif func in ("smaller", "bigger"):
            (width, height) = img.size  
            if func == "smaller":
                multiplier = 0.8
            else:
                multiplier = 1.2
            width = int(img.width * multiplier)
            height = int(img.height * multiplier)
            img.resize(width, height)
            (width, height) = img.size

            #print("image:" + str(img.width) + " " + str(img.height))
            #print("after:" + str(width) + " " + str(height))
            #return(json.dumps({'width':width,'height': height}))

    return(json.dumps({'width':width,'height': height}))
   
def renameFile(imageDir, oldName, newName):  
    path = webDir + imageDir + oldName + ".jpg";
    if os.path.isfile(path):
        x = os.rename(path, webDir + imageDir+ newName + ".jpg") 
        name = newName
    else:
        name = oldName
    return(name)

def saveFile(fileName):
    x = os.open(fileName, "w")
    return(newName)

def rmFile(fileName):
    x = os.open(fileName)
    return(newName)

def getRideLeaderInfo():
    addressList=[]
    fileName  = dataDir + "rideLeaders.csv"
    with open(fileName ,  'r') as read_obj:
    # pass the file object to reader() to get the reader object
        csv_reader = reader(read_obj)
    # Pass reader object to list() to get a list of lists
        list_of_rows = list(csv_reader)
        i = 0;
        for row in list_of_rows:
            if i == 0:
                keys = row
            else:
                j = 0
                newRow={}
                while j < len(row):
                    newRow.update( {keys[j] : row[j]})
                    j += 1
                addressList.append(newRow)
            i += 1                
        return(json.dumps(addressList))


def putRideLeaderInfo(data):
    fileName  = dataDir + "rideLeaders.csv"
    z = json.loads(data)
    lines = z.split("$")
    #  lines = z.split("\n")

    fp = open(fileName , 'w')
    for line in lines:
        fp.write( line + "\n")        
    fp.close()

def newYearReset(cal, mode):
    initCustomDef(cal)
    statusID, valueID = customNameToID({'status': ['choices']})
    statusID, confirmID = customNameToID({'Status': ['Confirmed'][0]})
    statusID, changeID = customNameToID({'Status: ': ['change'][0]})
    statusID, pendID = customNameToID({'Status': ['pend'][0]})         
    statusID, cancelID = customNameToID({'Status': ['cancel'][0]})             
    statusID, leaderID = customNameToID({'Status': ['leader'][0]})         

    today = dt.date.today()
    year = today.year
    month = today.month
    day = today.day
    if month <  6: 
        lastYear = year - 1
        nextYear = year
    else: 
        lastYear = year 
        nextYear = year + 1

    if mode == "lastYear":
        startDate = dt.date(lastYear, 1, 1)
        endDate = dt.date(lastYear, 12, 31)
    elif mode == "nextYear" or mode == "test":
        startDate = dt.date(nextYear, 1, 1)
        endDate = dt.date(nextYear, 12, 31)
    #print("YEARS" , lastYear,"  ",  nextYear)
        #  if repeat is yearly disconnect from pattern
    # disconnect perevious year
    rides = getEvents(cal, startDate, endDate)

    for ride in rides:
        if (ride['who'].lower()).find("needed") > -1:
            i=0
            
        if ride['rrule'].find('YEAR') == -1: 
            continue
        if 'custom' not in ride:
            continue
        if statusID not in ride['custom']:
            continue

        status = ride['custom'][statusID][0]
        results = ""
        if status != pendID:
            i=0
        if mode == "lastYear":
            ride['reddit'] = "single"
            #print("setting to single ", ride['start_dt'], " " , ride['title'])
            results = updateEvent(cal, ride)
        elif mode == "nextYear":
            status = pendID
            ride['redit'] = "all"
            ride['custom'][statusID][0] = pendID
            #print("updating to pending ", ride['start_dt'], " " , ride['title'], "to", ride['custom'][statusID])
            results = updateEvent(cal, ride)
        elif mode == "test":
            if status == changeID or status == pendID or status == leaderID:
                status = confirmID
                results = updateEvent(cal, ride)
                #print("updating to confirmed ", ride['start_dt'], " " , ride['title'], "to", ride['custom'][statusID])
                
        if isinstance(results , str):
            True
            #print(results)   

