import sys
import getopt

import json
import glob

import requests
from urllib.parse import quote
#from urllib.parse import unquote
##import ssl
import textwrap
from nested_lookup import nested_update, nested_delete, nested_lookup

import time
import datetime as dt
from dateutil.parser import parse
from dateutil.relativedelta import relativedelta

import string
import csv

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from overrides import *
#
# Teamup required
APIkey = "ca3fec0bc53190c90863e0f41579e27cbc98a57a97c909455df7db816f4ae4bd"
URL = 'https://api.teamup.com/'
PASSWORD_HEADERS = { 'Teamup-Password': '31A&T*Aha'}
PASSWORD_HEADERS = { 'Teamup-Password': 'EBC123#cal'}
HEADERS = {'Teamup-Token': APIkey}
UPDATE_HEADERS = {'Teamup-Token': APIkey, 'Content-type': "application/json"}
PASSWORD_HEADERS.update(UPDATE_HEADERS)
#UPDATE_HEADERS=HEADERS
#UPDATE_HEADERS.update(PASSWORD_HEADER)
# Default address for calendar contact andproblems
domain="python.ebcrides.org/one"
domain="localhost"
HEADERS.update(PASSWORD_HEADERS)
# Calendar IDs
#

CALENDAR_NAMES = {'EBCrides': "ksdtrd981nepm3brj9",
                  'EBCridesModify': "ksexyuw3mwu79svgv4",
                  'NewYearReset' : "ksgkg9m8bdrd3or989",
                  'EBCridesReadOnly': "ks4f2ityp82zqj3zsh",
                  'jaysRideSchedule': "ksbmqapicnorxb63e1",
                  'backup test' : 'c/o7ejzk/backup-test',
                  'durango': "ksv7sx99mt841o3dm3",
                  'new': "ksrdre9m4dz88zvpex"
                  }


def calendarPicker(heading):
    i = 0
    print(heading)

    cals  = sorted(CALENDAR_NAMES.items())
    while True:
        print ("{:^3s} {:^20s} {:^20s} ". \
               format("#", "Name", "ID" ))
        for entry in enumerate(cals):
            print ("{:2d}. {:20s} {:20s} ". \
                   format(entry[0], entry[1][0], entry[1][1]))
        i = int(input("Enter calendar number: "))

        if i < len(CALENDAR_NAMES):
            return(cals[i][1])
        else:
            print("Invalid choice: " + str(i) + ", try again.")

def filePicker(heading, pattern):
    cals = list(glob.iglob(pattern))
    print(heading)
    while True:
        for entry in enumerate(cals):
            print ("{:2d}. {:20s}". \
                   format(entry[0], entry[1]))
        i = int(input("Enter file number: "))
        if len(cals) == 0:
            return(None)
        if i < len(cals):
            return(cals[i])
        else:
            print("Invalid choice: " + str(i) + ", try again.")

def calIDToName(calID):
    for name, id in CALENDAR_NAMES.items():
        if id == calID:
            return (name)
    s = calID + "Not Found"
    print(s)
    return("")


def calNameToID(calName):
     if calName in CALENDAR_NAMES:
         return(CALENDAR_NAMES.get(calName))
     else:
         s = calName + " Not Found"
         print(s)
         return(None)


def getConfig(calendar):
    params = ""
    contentType = 'configuration'
    results = queryTeamup(HEADERS, calendar, 'get', contentType, params, {})

    if isinstance(results, str):
        return("Error: " + str(results))

    return (results[contentType])


#
# THese are the ride catagories
#
def getSubCalendars(calendar):
    params = ""
    contentType = 'subcalendars'
    results = queryTeamup(PASSWORD_HEADERS, calendar, 'get', contentType, params, {})
    if isinstance(results, str):
        print("Error getting subcalendars: " + results)
        exit()
# return (results['subcalendars'])
    return (results[contentType])


#
# get all events
#
customDef = dict()
def initCustomDef(calendar):
    global customDef
    if len(customDef) == 0:
        config = getConfig(calendar)
        customDef = config['fields']['definitions']


def createCustomFields(toCal, fileConfig):
     global  customDef

     match = False
     i = 0
     j = 0
     params=""
     update = False
     while i < len(fileConfig):
         fieldID = fileConfig[i]['id']
         fieldName = fileConfig[i]['name']
         config = fileConfig[i]
         if fieldID.find("built") > -1:
             i+=1
             continue
         j=0
         while j < len(customDef):
             toName = customDef[j]['name']
             toID = customDef[j]['id']
             if toName == fieldName:
                 config['id'] = toID
                 results = queryTeamup(UPDATE_HEADERS, toCal, 'put', 'field-definitions/', toID, config)
                 update=True
                 if isinstance(results, str):
                     print(results)
                 j+=1
                 break
             j+=1
         i += 1
         if update == True:
             update = False
             continue
         results = queryTeamup(UPDATE_HEADERS, toCal, 'post', 'field-definitions', params, config)

     i = 0
     j = 0
     params=""
     update = False
     while i < len(fileConfig):
         fieldID = fileConfig[i]['id']
         fieldName = fileConfig[i]['name']
         config = fileConfig[i]
         while j < len(customDef):
             toName = customDef[j]['name']
             toID = customDef[j]['id']
             if toName not in nested_lookup('name', customDef):
                 j += 1
                 continue
             swap = False
             if fieldID.find("built") > -1:
                 if toID != fieldID:
                     swap = True
                 elif toName != fieldName:
                     results = queryTeamup(UPDATE_HEADERS, toCal, 'put', 'field-definitions/', toID, config)

             if fieldID.find("built")  == -1:
                 if toName != fieldName:
                     swap = True
             if swap == True:
                 swap = False
                 i = 0
                 j = 0
                 results = queryTeamup(UPDATE_HEADERS, toCal, 'post', 'field-definitions/',fieldID + "/swapWith/" + toID , "")
                 if isinstance(results, str):
                     if results.find("field_limit_exceeded") > -1:
                         continue
                     print(i, " No definition for field ",  j, " " , fieldID, " ", results)
                 if 'definitions' not in results:
                     print ("Error: no definiions found")
                     return()
                 customDef = results['definitions']
                 break
             else:
                 i += 1
                 j += 1
                 break
     i=0
     
     
     
def getEvents(calendar, startDate, endDate):
    #
    # initailize custom fields
    initCustomDef(calendar)

    if isinstance(startDate, str):
        start = startDate
    else:
        start = dt.datetime.strftime(startDate, '%Y-%m-%d')
    if isinstance(endDate, str):
        end = endDate
    else:
        end = dt.datetime.strftime(endDate, '%Y-%m-%d')

    params = '?startDate=' + start + '&endDate=' + end

    DEBUG = 0
    data = {}
    contentType = 'events'
    results = queryTeamup(HEADERS, calendar, 'get', 'events', params, data)
    if len(results.get(contentType)) >= 0:
        return (results[contentType])
    elif results.get('error'):
        return (results['error'])
    else:
        # zero rows returned
        print("Unexpect query results ", results)
        exit()

#
# Get one event
#

# def deleteEvent(calendar, eventID, version):
#     params = '/' + eventID + "?version=" + version + "&redit=all"
#     DEBUG = 0
#     data = {}
#     results = queryTeamup(HEADERS, calendar, 'delete', 'events', params, data)
#     if  isinstance(results, str)  and results.find("200") > -1:
#         return ("Success")
#     else:
#         print("Unexpect query results in deleteEvent", results)
#         exit()

def getEvent(calendar, eventID):
    params = '/' + eventID
    DEBUG = 0
    data = {}
    initCustomDef(calendar)
    results = queryTeamup(HEADERS, calendar, 'get', 'events', params, data)
    if not isinstance(results, str):
        return (results['event'])
    else:
        print("Event not found getEvent", results)
        return("Error: Event not found getEvent" + str(results))
                #exit(-1)


def updateEvent(calendar, event):
#    if event['id'].find("rid") >= 0:
        ## + "?format=html&inputFormat=html
 #       params = '/' + event['id'].partition('-rid-')[2]
  #  else:
    params = '/' + event['id']
    #print(json.dumps(event, indent=4))
    results = queryTeamup(UPDATE_HEADERS, calendar,
                          'put', 'events', params, event)
    if isinstance(results, str):
        print("Error: " +  str(results).replace('\\"', ''))
        return("Error: " + str(results))
    return(results)



def fuzzyCompare(name1, name2):
    if name1 == "":
        return False
    import re
    chars=":|!|.|?|(|)|,|;"
    chars=":|!|.|?|(|)|,"

    nm1 = (name1.upper()).strip()
    nm1 = re.sub(":|!", "", nm1)
    nm2 = (name2.upper()).strip()
    nm2 = re.sub(":|!", "", nm2)
    if  nm2.find(nm1) > -1:
    #if  (name2.upper().strip()).find((name1.upper().strip())) > -1:
    #if name1 == name2:
        return True
    else:
        return False

custom = dict()
def getCustomDefs(definitions=None):
    global customDef
    xx = list()
    e = {}
    if definitions == None:
        definitions = customDef
    for d in definitions:
        if d['type'].find("builtin") != -1:
           continue
        if d['active'] == False:
           continue
        if 'type_data' in d:
            x = nested_lookup(d['type_data'], 'name')
            #print("\n\n x", x)
            y = d.get('name', d.get('options', d['type_data']))
            #print("\n\ny", y, "x", x)
            e.update({d.get('name'): x})
            i=0
        else:
           e.update({d.get('name'): 'none' })
        xx.append(e)
    return(xx)
    
    
def customNameToID(customNames, definitions=None):
    global customDef
    global custom
    if definitions == None:
        definitions = customDef
 
    def id(name,x):
        ids = nested_lookup('id', x,)
        names = nested_lookup('name', x)
        z = 0
        while z < len(names):
            #if  (name[z].upper().strip()).find((name.upper().strip())) > -1:
            if fuzzyCompare(name, names[z]) == True:
                return(ids[z])
            z += 1

    for fieldName, valueName in customNames.items():
        fieldID = None
        for row in iter(definitions):
            if row['active'] == False or row['name'] == "":
                continue
            if fuzzyCompare(fieldName, row['name'] ) == False:
            #if (row['name'].strip()).upper().find(nm) == -1:
                continue
            fieldID = row['id']
            break;

        # fieldID should be defined here
        if fieldID == None:
            print("\twarning: couldn't find ", fieldName, " in definitions ")
            x = zip(['id', 'name', 'active', 'type'], ['notfound', fieldName,  True, 'single_line_text'])
            definitions.append(dict(x))
            return(None, fieldName)

        if row['type'] == "single_line_text":
            custom.update({ fieldID: valueName})
            return(fieldID, valueName)
        #
        # only one name passed in
        if valueName == None:
            return(fieldID,  None)

        options = nested_lookup('options', row, wild=True)
        if isinstance(valueName, list):
            i = 0
            valueID = list()
            while i < len(valueName):
                nm = id(valueName[i], options)
                valueID.append(nm)
                #print(name(ID[i], options))
                i += 1
        else:
            valueID = id(valueName, options)
            #print("Val:" , ID)
        custom.update({fieldID : valueID})
        return(fieldID, valueID)

def customIDToName(customIDs, definitions=None):
    global customDef
    if definitions == None:
        definitions = customDef

    global custom

    def name(id, x):
        ids = nested_lookup('id', x)
        name = nested_lookup('name', x)
        z = 0
        if id == 'choices':
            return(name)
        for z in range(len(ids)):
            if  ids[z] == id:
                return(name[z])


    custom.clear()
    if customIDs == None:
        return({})
    for fieldID, valueID in customIDs.items():
        if fieldID == None:
            return([None, None])
        #print(fieldID, " ", valueID)
        for row in iter(definitions):
            fieldName = None
            if row['id'] != fieldID:
                continue
            fieldName = name(fieldID, row)
            break
        if fieldName == None:
            print("Couldn't find fieldID: ", fieldID, "in Definitions:")
            definitions.update({'id': fieldID},{'name': "Not Found"})
            return([fieldID,valueID])

        if valueID == []:
            valueName = []
        elif isinstance(valueID, list):
            valueName = list()
            options = nested_lookup('options', row, wild=True)
            for i in range(len(valueID)):
                nm = name(valueID[i], options)
                #print(nm, valueID[i])
                valueName.append(nm)
        elif row['type'] == "single_line_text":
            valueName = valueID
        else:
            valueName = name(valueID, None)
        #custom[fieldName] = valueName
    return([fieldName, valueName])

# def customValueToName(customID, matchName=None, definitions=None):
#     x, valueName = customIDToName(customID, definitions).popitem()
#     if matchName == None:
#         return(valueName)
#     else:
#         if isinstance(valueName, list):
#             for i in range(len(valueName)):
#                 if (matchName.strip()).upper() == (valueName[i].strip()).upper():
#                     return(True)
#         elif (matchName.strip()).upper() == (valueName.strip()).upper():
#             return(True)
#         return(False)


# def getFields(calendar):

#     DEBUG = 0


#     params = ""
#     data = {}
#     contentType = 'field-definitions'
#     results = queryTeamup(HEADERS, calendar, 'get', contentType, "", data)
#     contentType = 'definitions'
#     if isinstance(results, str):
#         print("Unexpect query results getting field definitions", results)
#         exit(1)
#     elif results.get(contentType):
#         return (results[contentType])
#     else:
#         results.get('error')
#         return (results['error'])


def queryTeamup(headers, calendar, oper, contentType, params, data):
    url = URL + calendar + '/' + str(contentType) + str(params)
    if oper == 'get':
        params = ""
    #
    # data=json.dumps(data)????
    #
        response = requests.get(
            url=url, headers=headers, params=params, data=data)
    elif oper == 'delete':
        if data != "":
            params=params + "/"
        url += data
        response = requests.delete(url=url, headers=headers)
    elif oper == 'post':
        response = requests.post(url=url, headers=headers,
                                 data=json.dumps(data))
    elif oper == 'put':
        response = requests.put(url=url, headers=headers, data=json.dumps(data))
    else:
        response.status_code = -1
        response.text = "ERROR: Invaled operation request: " + oper

    if response.status_code > 300:
        results = "Error: " + str(response.status_code) + " " + response.reason + json.dumps(response.text)
        return(results)

    if oper != 'delete':
#        if sys.version_info[0] == 3 and sys.version_info[1] < 6:
#            results = json.loads(response.text)
#        else:
        results = json.loads(response.content)
    else:
        results = str(response.status_code) + ". " + response.reason
    return(results)

# probably out of scope?


# def createEmptyObj(obj, new):
#     new = fileEvent.copy()
#     for k in new.keys():
#         new[k] = None
#     return(new)


results = list()


# def printEvent(d, k):
#     results = keyValue(d, k)
#     results = str(results)
#     results = results.replace("[", "")
#     results = results.replace("]", "")
#     results = results.replace("'", "")
#     print(results)
#     return(results)


# def printKeyValue(data, keyNames, endStr=""):
#     printEvent(data, keyNames)


debug = 0


def keyValue(data, keyNames):
    ret = []
    ret.clear()
    st = str()

    def keyValue2(data, keyNames):
        if isinstance(data, list):
            for i in data:
                #if debug:
                    #print("one ", i)
                keyValue2(i, keyNames)
        elif isinstance(data, dict):
            for i, j in data.items():
                if isinstance(j, dict):
                    #if debug:
                        #print("2. i:", i, "j: ")
                    keyValue2(j, keyNames)
                if keyNames == i:
                    if debug:
                        #print("3. keyNames ", keyNames, "i: ", i)
                        exit(1)
                    if isinstance(data[i], str):
                        s = data[i].encode('ascii', 'ignore')
                        data[i] = s.decode()
                    ret.append(data[i])
                    return(ret)

    if isinstance(keyNames, set):
        for key in keyNames:
            keyValue2(data, key)
        # return(ret)
    else:
        keyValue2(data, keyNames)
    if len(ret) == 1:
        return(ret[0])
    return(ret)


def fromTeamupDate(date):
    d = parse(date)
    if d.minute == 0 and d.hour == 0:
        rdate = dt.datetime.strftime(d, '%m/%d/%Y')
    else:
        rdate = dt.datetime.strftime(d, '%m/%d/%Y %H:%M')
    return(rdate)


# def toTeamupDate(date):
#     p = parse(date)
#     tdate = str(dt.datetime.strftime(p, '%Y-%m-%dT%H:%M:%S'))
#     return(tdate)



# def id2name(calendars, i=0):
#     if isinstance(i, str):
#         id = int(i.partition("-rid'")[2])
#     for cal in calendars:
#         #     for key in cal:
#         if cal['id'] == i:
#             return (cal['name'])
#     return ("calendar id ", i, " not found")



def subCalNameToID(calendars, name):
     for cal in calendars:
#         print("\n[[", cal['name'], "[[\n[[", name, "]]\n")
         if cal['name'].strip() == name.strip():
             return (cal['id'])
     return (-1)

def matchKeyVal(array2, array1Key, lookUpKeyMatch, lookUpKey):
    for row in array2:
        for key in row:
            if key == lookUpKeyMatch:
                x = row[lookUpKey]
                return(x)
    return("")

def subCalIDToName(calendars, ids, all=True):
    # subalaendars are now an array if the depricated
    # subcalendar field is passed in, make it a list
    calNames = ""
    if not isinstance(ids, list):
        ids = [ids]
    for cal in calendars:
        for id in ids:
            if cal['id'] == id:
                if cal['active'] != True:
                    i=0
                if all == False:
                    return (cal['name'])
                else:
                    calNames = calNames + " " + cal['name']
    if calNames == "":
        return (-1)
    else:
        return(calNames)


# def tuTime(date):
#     dt.datetime.strftime('%H=%m-%s')
#     return(date.split('T')[0][0:8])


# def tuDate(date):
#     date = dt.datetime.strftime(date, '%Y-%m-%d')
#     return(date)


leaders = list()
#rideLeaderFile="data/rideLeaders.csv"
def getRideLeaders():
    global leaders
    rideLeaderFile=dataDir + "/rideLeaders.csv"
    with open(rideLeaderFile, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        i = 0
        for row in reader:
            leaders.append(dict(row))
        csvfile.close()

def addressBook(rideLeader):
    global leaders

    if len(leaders) == 0:
        getRideLeaders()
    if rideLeader == 'ridesChair':
        return('ridesChair@evanstonbikeclub.org')

    sendTo = None
    # only one name on ride, set it to be the last name wih ??? as the first naem
    if len(rideLeader.split()) < 1:
        rideLeader = "??? ???"
    elif len(rideLeader.split()) < 2:
        rideLeader = "??? " + rideLeader
    #while True:
    # first check for a match on first and last name in the ride leaders file
    first = rideLeader.split()[0].capitalize()
    last = rideLeader.split()[1].capitalize()
    names = []
    emailAddr = ""
    for row in leaders:
        if row['Last'].capitalize() == last:
            names.append(row)

    if len(names) == 0:
        return("not found")
    else:
        for row in names:
            if row['First'].capitalize() == first:
                emailAddr = row['email']
        if emailAddr == "":
            msg = "No match found for first name in Club Express for: " + first + " " + last
            msg += "<br> You should probably change it to what Club Express uses, " + row['First'] + " " + row['Last']
            msg + " or change the name in Club Express to use " + first + " " + last + "."
            email(msg, ridesChair, ridesChair, 
                  "ERROR: " + rideLeader + " not found in email address book") 
            return("not found")
        i = rideLeader.find("/")

    if i > -1:
        #print("Leader", rideLeader, " Co Leader is: ", rideLeader[i+1:])
        coLeader = addressBook(rideLeader[i+1:])
        emailAddr += "," + coLeader
    return(emailAddr)

from email.message import EmailMessage
from email.headerregistry import Address
def email(body, fromName, toName, subject, sendEmail=True):
    text = str()

    #if fuzzyCompare("leader needed", toName):
        #return False

    if toName.find("rides") > -1:
        toAddr = "ridesChair@ebcrides.org"
    else:
        toAddr = addressBook(toName)
        
    if fromName.find("rides") > -1:
        fromAddr = "ridesChair@ebcrides.org"
    else:
        fromAddr = addressBook(fromName)
    
    if toAddr == "not found":
        msg = "ERROR: " + toName + " not found in email address book";
        #body = "While trying to send an email TO " + toName + "."
        print(msg)
        #email(body, ridesChair, ridesChair, msg        return(msg)

    #if fromAddr == "not found":
        msg = "ERROR: " + fromName + " not found in email address book";
        #body = "While trying to send an email FROM " + fromName + "."
        print(msg)
        #email(body, ridesChair, ridesChair, msg)
        return(msg)

    print("mail:", subject, "to ", toAddr)
    if toName.find("rides") > -1:
        # rides chair bound email
        #toAddr = "HeelanWill@gmail.com"
        #toAddr = "will@ebcrides.org"
        toAddr = "jaytwery@ebcrides.org"
    else:
        # ride leader bound email
        #toAddr = "jaytwery@gmail.com"
        #toAddr = "HeelanWill@gmail.com"
        toAddr = "jaytwery@ebcrides.org"

    #toAddr = "will@ebcrides.org"
    msg = EmailMessage()
    
    if fromAddr != ridesChair:
        print("ERROR FROM ADDRESS is " + fromAddr +  " " + subject)

    #msg['From'] = "ebcrides8#gmailYou.com"
    msg['From'] = fromAddr
    msg['To'] = toAddr
    msg['Subject'] = subject
#    body = body.replace('alt=""','alt="foo.jpg"')
    body = textwrap.fill(body, 69)
    msg.set_content(body, subtype='html')
    SMTPlogin = "rideschair@ebcrides.org"
    SMTPpass = "EBC55555rideschair"
    SMTPhost = "mail.ebcrides.org"
    #port 465 = SSL, port 587 =TTL
    #SMTPlogin = "jaytwery2@gmail.com"
    #SMTPpass = "BUC#vz56"
    #SMTPhost = "smtp.gmail.com"
  
    if sendEmail == False:
        print(msg)
        return()
    print("\nSending Email to: " + toAddr + "\n")
    #print("SMTPlogin: ", SMTPlogin, "\n")
    with smtplib.SMTP_SSL(SMTPhost, port=465) as smtp_server:
        smtp_server.ehlo()
#        smtp_server.starttls()
        smtp_server.login(SMTPlogin, SMTPpass)
        smtp_server.send_message(msg)
        smtp_server.quit()
    return("")


#class rides:
#  def __init__(self, rideLeader, startDate, endDate):
#    self.rideLeader = rideLeader
#    self.startDate = startDate
#    self.endDate = endDate

#  def myfunc(self):
#    print("Hello my name is " + self.rideLeader)



def restoreSubCals(liveSubCalendars, fileEvent):

     id = subCalNameToID(liveSubCalendars, fileEvent['subcalendar_id'])
     if id == -1:
             #
             # if not found, need to set it to something...
         print("\tWarning: ", fileEvent['subcalendar_id'], ' not found, setting to ', liveSubCalendars[0]['name'], ".")
         id = liveSubCalendars[0]['id']
     fileEvent['subcalendar_id'] = id
     subcals = fileEvent['subcalendar_ids']

     # make a list of subcalendars this ride is part of
     #
     ids = list()
     for subCalendar in subcals:
         id = subCalNameToID(liveSubCalendars, subCalendar)
         if id == -1:
             #   if debug:
         #        print("removing ", subCalendar, end=" ")
             continue
 #           print("\n\t subcalendar list changed", x, " to numbercal ", id, end=" ")
         ids.append(id)
     fileEvent['subcalendar_ids'] = ids
     if isinstance(fileEvent['subcalendar_id'], str):
         print('ERROR: this shoudnot happen skipping, ',
               fileEvent['subcalendar_id'], ' should not be a string.')
         exit()


#
# end function
def timestamp(time = dt.datetime.now()):
    return(dt.datetime.strftime(dt.datetime.now(), '%m/%d %H:%M:%S.%f'))
