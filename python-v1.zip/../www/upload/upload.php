<?php
$f = fopen("foo2", "w");
include("./overrides.php");

$images_dir = "../images/cal/";
if (empty($_FILES)) {
	return;
        }

fwrite($f, "images: " .$images_dir);
move_uploaded_file($_FILES["file"]["tmp_name"], $images_dir.$_FILES['file']['name']);
$file=$images_dir . $_FILES['file']['name'];
fwrite($f, "in update 2 in: " );
fwrite($f, $_FILES["file"]["tmp_name"]. "\n"); 
fwrite($f,  "out:  " .  $images_dir.$_FILES['file']['name']. "\n");
fwrite($f,  "opening usig image magik:  ");
$image = new Imagick($file);

fwrite($f,  "past open forimage magik \n ");
/* scale the image to the best fit for 300 px */
$image->scaleImage(201,200,true);

/* straighten the image */

$orientation = $image->getImageOrientation(); 
    switch($orientation) { 
        case imagick::ORIENTATION_BOTTOMRIGHT: 
            $image->rotateimage("#000", 180); // rotate 180 degrees 
        break; 

        case imagick::ORIENTATION_RIGHTTOP: 
            $image->rotateimage("#000", 90); // rotate 90 degrees CW 
        break; 

        case imagick::ORIENTATION_LEFTBOTTOM: 
            $image->rotateimage("#000", -90); // rotate 90 degrees CCW
        break; 
    } 

    // Now that it's auto-rotated, make sure the EXIF data is correct in case the EXIF gets saved with the image! 
    $image->setImageOrientation(imagick::ORIENTATION_TOPLEFT);

// convert to jpg
$image->setImageFormat("jpg");
$dim=$image->getImageGeometry(); 
header("Content-type: image/jpg");
$path_parts = pathinfo($file);

$newName = $path_parts['dirname']. "/" . $path_parts['filename'] . ".jpg";
fwrite($f, "\n diminsions: ". $dim['width'] . "by" .$dim['height']);
$xy= array($dim['width'], $dim['height']);
$image->writeImage($newName);
$image->destroy();
fwrite($f,  "out after image magik:  " .  $newName . " returning ");
fwrite($f,  implode(",", $xy) . "\n ");
fclose($f);
print(implode(",", $xy));
// print($xye);
?>
